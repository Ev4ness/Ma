# [κ λ z υ]

## 📨 Contact me on [![Telegram](https://img.shields.io/badge/telegram-1b77FF.svg?style=for-the-badge&logo=telegram)](https://t.me/disinikazu) 
<br>

### Stats:
<p align="center"><a href="https://github.com/ionmusic"><img src="https://github-readme-stats.vercel.app/api?username=ionmusic&show_icons=true&theme=radical"></a></p>
<p align="center"><a href="https://github.com/ionmusic"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=ionmusic&theme=radical&layout=compact"></a></p> 

### Let's connect!
<p>
    <a href="https://t.me/ionmusic" target="blank"><img src="https://img.shields.io/badge/@disinikazu-30302f?style=flat&logo=telegram" /></a>
    <a href="https://instagram.com/r_simberi" target="blank"><img src="https://img.shields.io/badge/@r_simberi-30302f?style=flat&logo=instagram" /></a>
</p>
<details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=ionmusic)

</details>

<details>
    <summary>&#127942 <b>GitHub Activity</b></summary><br/>

![Metrics](https://metrics.lecoq.io/ionmusic?template=classic&repositories.forks=true&languages=1&languages.colors=github&languages.threshold=0%25&config.timezone=Asia%2FJakarta)

</details>
